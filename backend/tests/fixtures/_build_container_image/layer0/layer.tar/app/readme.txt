base layer
