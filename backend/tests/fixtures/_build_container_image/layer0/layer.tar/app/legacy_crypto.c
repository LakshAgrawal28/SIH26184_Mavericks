EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
